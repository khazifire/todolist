import {
  IonApp,
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonPage,
  IonItem,
  IonList

} from '@ionic/react';
import React from 'react';
import { Link } from 'react-router-dom';
import { entries } from '../data';

const Homepage: React.FC = () => {
  return (
    <IonPage>
      <IonHeader>
 <IonToolbar>
          <IonTitle>Mango Home</IonTitle>
          </IonToolbar>
      </IonHeader>
      <IonContent className="ion-padding">
        <IonList>
          { entries.map((entry) => 
          <IonItem button key={entry.id}
            routerLink={`/my/entry/${entry.id}`}>
            {entry.title}
        </IonItem>
          )}
        </IonList>
      </IonContent>
      </IonPage>
  );
};

export default Homepage;
